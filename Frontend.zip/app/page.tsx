"use client";
import { useState, useRef, useEffect } from 'react';

type Message = {
  role: 'user' | 'assistant';
  content: string;
  context?: string;
};

export default function ChatOrchestrator() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [latestContext, setLatestContext] = useState<string | null>(null);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const res = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userMessage }),
      });
      
      const data = await res.json();
      
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: data.response,
        context: data.context_used 
      }]);
      
      // Update the side panel with the latest context
      setLatestContext(data.context_used);
      
    } catch (error) {
      console.error("Error communicating with backend:", error);
      setMessages(prev => [...prev, { role: 'assistant', content: "Error connecting to the orchestrator." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-gray-100 font-sans text-gray-900 overflow-hidden">
      
      {/* LEFT PANEL: Chat Interface */}
      <div className="flex flex-col w-2/3 h-full border-r border-gray-300 bg-white">
        
        {/* Chat Header */}
        <div className="px-6 py-4 border-b border-gray-200 bg-white shadow-sm z-10">
          <h1 className="text-xl font-bold text-gray-800">Agentic AI Chat</h1>
          <p className="text-sm text-gray-500">Powered by Fastapi, Vector DB & Groq</p>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-gray-50">
          {messages.length === 0 && (
            <div className="h-full flex items-center justify-center text-gray-400">
              Start a conversation to see the context engine in action...
            </div>
          )}
          
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`px-5 py-3 max-w-[80%] rounded-2xl shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-br-none' 
                  : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none'
              }`}>
                <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>
              </div>
            </div>
          ))}
          
          {loading && (
            <div className="flex items-start">
              <div className="px-5 py-3 rounded-2xl bg-gray-200 text-gray-600 rounded-bl-none animate-pulse">
                Orchestrator is retrieving vectors...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-gray-200">
          <form onSubmit={sendMessage} className="flex gap-3 max-w-4xl mx-auto">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message here..."
              className="flex-1 p-4 bg-gray-100 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-colors text-gray-900 placeholder-gray-500"
            />
            <button 
              type="submit" 
              disabled={loading || !input.trim()}
              className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Send
            </button>
          </form>
        </div>
      </div>

      {/* RIGHT PANEL: System Context Viewer */}
      <div className="flex flex-col w-1/3 h-full bg-slate-900 text-gray-300">
        <div className="px-6 py-4 border-b border-slate-700 bg-slate-950">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            System Context Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1">Data injected into the LLM prompt</p>
        </div>
        
        <div className="flex-1 p-6 overflow-y-auto">
          {latestContext ? (
            <div className="space-y-4">
              <div className="text-sm text-slate-400 font-mono mb-2">
                // Retrieved from Vector DB
              </div>
              <pre className="p-4 bg-slate-800 border border-slate-700 rounded-lg text-sm font-mono text-green-400 whitespace-pre-wrap shadow-inner overflow-x-auto">
                {latestContext}
              </pre>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-600 space-y-4 text-center">
              <svg className="w-12 h-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
              <p>No context retrieved yet.<br/>Send a message to trigger the vector search.</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}